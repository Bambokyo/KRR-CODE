from flask import Flask,render_template,request
from rdflib import Graph

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/', methods=['POST'])
def queryLocalGraph():
    qn= request.form['qn']
    g = Graph()
    g.parse("plsWork.ttl", format="ttl")
    
    print("Loaded '" + str(len(g)) + "' triples.")
    

    w = """
            PREFIX dbp: <http://dbpedia.org/property/'>
            PREFIX dbo: <http://dbpedia.org/ontology/>
            PREFIX : <http://www.krrproject.com/CrimeOntology#>
            prefix owl: <http://www.w3.org/2002/07/owl#> 
            prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
            prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
            prefix xsd: <http://www.w3.org/2001/XMLSchema#>
            select * 
            WHERE 
            {
                ?s :typesOfCrimes ?o.   
            }


"""
    qres = g.query(w)
    
    for row in qres:
        #Row is a list of matched RDF terms: URIs, literals or blank nodes
        print((str(row.s),str(row.o)))
    return render_template('pass.html',n=qres)

@app.route('/', methods=['POST'])
def getval():
    qn= request.form['qn']
    return render_template('pass.html',n=qn)


if __name__ == "__main__":
    app.run(debug=True,port=800)
